<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="refresh" content="5" >
    <link rel="stylesheet" type="text/css" href="style2.css" media="screen"/>

	<title> Sensor Data </title>

</head>

<body>

    <h1>DATA FROM DATABASE</h1>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "iotdb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT id, status, speed, date FROM table_fan ORDER BY id DESC"; 
echo '<table cellspacing="5" cellpadding="5">
      <tr> 
        <th>ID</th> 
        <th>Status</th>  
        <th>Speed</th>     
        <th>Date</th> 
      </tr>';
 
if ($result = $conn->query($sql)) {
    while ($row = $result->fetch_assoc()) {
        $row_id = $row["id"];
        $row_status = $row["status"];
        $row_speed = $row["speed"];
        $row_date = $row["date"];
        $speedy = "";
        if ($row_speed == "250" )
        {
            $speedy = "HIGH";
        }
        else if($row_speed == "110")
        {
            $speedy = "MEDIUM";
        }
        else if($row_speed == "50")
        {
            $speedy = "LOW";
        }
        else
        {
            $speedy = "NONE";
        }
      
        echo '<tr> 
                <td>' . $row_id . '</td> 
                <td>' . $row_status . '</td> 
                <td>' . $speedy. '</td> 
                <td>' . $row_date. '</td> 
                
              </tr>';
    }
    $result->free();
}
$conn->close();
?> 
</table>

</body>
</html>

	</body>
</html>