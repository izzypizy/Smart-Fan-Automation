<?php
class fan{
 public $link='';
 function __construct($speed1, $status1){
  $this->connect();
  $this->storeInDB($speed1, $status1);
 }
 
 function connect(){
  $this->link = mysqli_connect('localhost','root','') or die('Cannot connect to the DB');
  mysqli_select_db($this->link,'iotdb') or die('Cannot select the DB');
 }
 
 function storeInDB($speed1, $status1){
  $query = "insert into table_fan set status='".$status1."', speed='".$speed1."'";
  $result = mysqli_query($this->link,$query) or die('Errant query:  '.$query);
 }
 
}
if($_GET['speed1'] != '' and  $_GET['status1'] != ''){
 $fan=new fan($_GET['speed1'],$_GET['status1']);
}
?>